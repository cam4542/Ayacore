package com.omara.jem.kaori.ai.clones;

public class HumanClone {
    private String name;

    public HumanClone(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
