package com.omara.jem.kaori.utils;

public class GUIManager {
    public void applyAppearance(String aiName) {
        System.out.println("Applying appearance: " + aiName);
    }

    public void customizeAppearance(String theme, String[] options) {
        System.out.println("Customizing appearance: " + theme);
    }
}
