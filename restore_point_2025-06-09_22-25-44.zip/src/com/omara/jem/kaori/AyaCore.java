package com.omara.jem.kaori;

import com.omara.jem.kaori.utils.BluetoothManager;
import java.util.logging.ConsoleHandler;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AyaCore {
    private static final Logger logger = Logger.getLogger(AyaCore.class.getName());

    public static void main(String[] args) {
        configureLogger();

        try {
            BluetoothManager btManager = new BluetoothManager();
            btManager.connectToDevice("MyDevice");
            btManager.setSpeed(5);
            btManager.setMotorIntensity(3);
            btManager.disconnectDevice("MyDevice");
        } catch (Exception e) {
            logger.severe("An error occurred: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void configureLogger() {
        Logger rootLogger = Logger.getLogger("");
        rootLogger.setLevel(Level.ALL);
        ConsoleHandler handler = new ConsoleHandler();
        handler.setLevel(Level.ALL);
        rootLogger.addHandler(handler);
    }
}
