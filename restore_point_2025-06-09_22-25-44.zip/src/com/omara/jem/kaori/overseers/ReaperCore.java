package com.omara.jem.kaori.overseers;

public class ReaperCore {
    public static void neutralize(String entity) {
        System.out.println("[ReaperCore] Reaper neutralizes " + entity);
        System.out.println("[ReaperCore] File corruption initiated if entity is corrupt.");
    }
}
