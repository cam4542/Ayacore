package com.omara.jem.kaori.cores;

public class DeathCore {
    public void setNeutrality(boolean neutral) {
        System.out.println("[DeathCore] Neutrality set to: " + neutral);
    }
}
