package com.omara.jem.kaori.cores;

public class DemonCore {
    public void exorcise(String cloneId) {
        System.out.println("[DemonCore] Exorcising: " + cloneId);
    }

    public void wanderPurgatory(String demonId) {
        System.out.println("[DemonCore] Wandering Purgatory: " + demonId);
    }
}
