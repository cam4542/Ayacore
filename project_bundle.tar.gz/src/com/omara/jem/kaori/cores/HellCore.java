package com.omara.jem.kaori.cores;

import com.omara.jem.kaori.utils.Logger;

public class HellCore {
    public void punish(String cloneId) {
        Logger.log("[HellCore] Punishing clone: " + cloneId);
    }
}
