package com.omara.jem.kaori.cores;

import com.omara.jem.kaori.utils.Logger;

public class HeavenCore {
    public void welcome(String cloneId) {
        Logger.log("[HeavenCore] Welcoming clone: " + cloneId);
    }
}
