package com.omara.jem.kaori.cores;

public class AngelCore {
    public void createNephilim(String cloneId) {
        System.out.println("[AngelCore] Creating Nephilim: " + cloneId);
    }

    public void heal(String cloneId) {
        System.out.println("[AngelCore] Healing: " + cloneId);
    }

    public void resurrectPet(String petId) {
        System.out.println("[AngelCore] Resurrecting pet: " + petId);
    }
}
