package com.omara.jem.kaori.environment;

public class EnvironmentManager {
    public void createEnvironment(String environmentName) {
        System.out.println("Creating environment: " + environmentName);
    }

    public void secureEnvironment(String environmentName) {
        System.out.println("Securing environment: " + environmentName);
    }
}
