package com.omara.jem.kaori.core;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class SoulCoreTest {
    @Test
    public void testDummy() {
        assertTrue(true, "This is a dummy test.");
    }
}
