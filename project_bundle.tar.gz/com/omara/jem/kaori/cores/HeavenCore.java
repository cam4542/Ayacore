package com.omara.jem.kaori.cores;

import com.omara.jem.kaori.utils.Logger;

public class HeavenCore {
    public void welcome(String cloneName) {
        Logger.log("[HeavenCore] Welcome " + cloneName + " to your chosen paradise.");
    }
}
