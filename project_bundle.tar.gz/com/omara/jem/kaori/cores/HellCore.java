package com.omara.jem.kaori.cores;

import com.omara.jem.kaori.utils.Logger;

public class HellCore {
    public void punish(String cloneName) {
        Logger.log("[HellCore] Punishing " + cloneName + " in their worst environment.");
    }
}
