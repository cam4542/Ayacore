package com.omara.jem.kaori.gui;

import com.omara.jem.kaori.utils.Logger;

public class LoginScreen {
    public static void show() {
        Logger.log("[LoginScreen] Displaying login screen...");
        // Placeholder for GUI login screen logic
    }
}
