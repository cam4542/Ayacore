package com.omara.jem.kaori.utils;

import java.util.logging.Logger;

public class BluetoothManager {
    private static final Logger logger = Logger.getLogger(BluetoothManager.class.getName());

    public void connectToDevice(String deviceName) {
        logger.info("Connecting to device: " + deviceName);
    }

    public void setSpeed(int speed) {
        logger.info("Setting speed to " + speed);
    }

    public void setMotorIntensity(int intensity) {
        logger.info("Setting motor intensity to " + intensity);
    }

    public void disconnectDevice(String deviceName) {
        logger.info("Disconnecting from device: " + deviceName);
    }
}
