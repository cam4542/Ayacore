package com.omara.jem.kaori.core;

public class SoulCore {
    private String deviceName;

    public SoulCore(String deviceName) {
        this.deviceName = deviceName;
    }

    public void connect() {
        System.out.println("Connecting to device: " + deviceName);
        // Add your BluetoothManager.connectDevice() logic here
    }

    public void disconnect() {
        System.out.println("Disconnecting from device: " + deviceName);
        // Add your BluetoothManager.disconnectDevice() logic here
    }

    public void setSpeed(int speed) {
        System.out.println("Setting speed to " + speed);
        // Add your BluetoothManager.setSpeed() logic here
    }

    public void setMotorIntensity(int intensity) {
        System.out.println("Setting motor intensity to " + intensity);
        // Add your BluetoothManager.setMotorIntensity() logic here
    }
}
